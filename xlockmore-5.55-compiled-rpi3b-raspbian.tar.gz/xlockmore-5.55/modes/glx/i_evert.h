#include <GL/gl.h>

extern double scale;
extern double width;
extern int sphere;
extern int torscene;
extern double corrstart, pushstart, twiststart, untwiststart, uncorrstart;
